package com.UCalculator.calculator

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.WindowManager
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.children
import com.UCalculator.calculator.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity()
{

    private lateinit var binding : ActivityMainBinding
    

    private var firstnumber = ""
    private var currentNumber = ""
    private var currentOperator = ""
    private var result = ""
    private var operatorClickable = true
    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState : Bundle?)
    {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        

        window.setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)

        binding.apply {

            binding.layoutMain.children.filterIsInstance<Button>().forEach { button ->

                button.setOnClickListener {

                    val buttonText = button.text.toString()
                    when{
                        buttonText.matches(Regex("[0-9]"))->{
                            if(operatorClickable){
                                if(currentOperator.isEmpty())
                                {
                                    firstnumber+=buttonText
                                    tvResult.text = firstnumber
                                }else
                                {
                                    currentNumber+=buttonText
                                    tvResult.text = currentNumber
                                }
                            }
                        }
                        buttonText.matches(Regex("[+\\-*/]"))->{
                            currentNumber = ""
                            if (tvResult.text.toString().isNotEmpty())
                            {
                                currentOperator = buttonText
                                tvResult.text = firstnumber
                                operatorClickable = true
                                disableOperatorButtons()


                            }
                        }
                        buttonText == "="->{
                            if (currentNumber.isNotEmpty()&& currentOperator.isNotEmpty())
                            {
                                tvFormula.text = "$firstnumber$currentOperator$currentNumber"
                                result = evaluateExpression(firstnumber,currentNumber,currentOperator)
                                firstnumber = result
                                tvResult.text = result
                                operatorClickable = false
                                enableOperatorButtons()
                            }
                        }
                        buttonText == "."->{
                            if(currentOperator.isEmpty())
                            {
                                if (! firstnumber.contains("."))
                                {
                                    if(firstnumber.isEmpty())firstnumber+="0$buttonText"
                                    else firstnumber +=buttonText
                                    tvResult.text = firstnumber
                                }
                            }else
                            {
                                if (! currentNumber.contains("."))
                                {
                                    if(currentNumber.isEmpty()) currentNumber+="0$buttonText"
                                    else currentNumber +=buttonText
                                    tvResult.text = currentNumber
                                }
                            }
                        }
                        buttonText == "C"->{
                            currentNumber = ""
                            firstnumber = ""
                            currentOperator = ""
                            tvResult.text = "0"
                            tvFormula.text = ""
                            operatorClickable = true
                            enableOperatorButtons()

                        }
                    }

                }
            }
            
            
        }
    }
    

     private fun evaluateExpression(firstNumber:String,secondNumber:String,operator:String):String
     {
         val num1  = firstNumber.toDouble()
         val num2  = secondNumber.toDouble()
         return when(operator)
         {
             "+"-> (num1+num2).toString()
             "-"-> (num1-num2).toString()
             "*"-> (num1*num2).toString()
             "/"-> (num1/num2).toString()
             else ->""
         }
     }
    private fun disableOperatorButtons() {
        binding.layoutMain.children.filterIsInstance<Button>().forEach { button ->
            val buttonText = button.text.toString()
            if (buttonText.matches(Regex("[+\\-*/]"))) {
                button.isClickable = false

                button.isEnabled = false
            }
        }
    }


    private fun enableOperatorButtons() {
        binding.layoutMain.children.filterIsInstance<Button>().forEach { button ->
            button.isClickable = true
            // Optionally, you can also set the button's appearance to reflect its enabled state
            button.isEnabled = true
        }
    }
}













































